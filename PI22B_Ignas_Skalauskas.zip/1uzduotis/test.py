import networkx as nx
print(f"NetworkX version: {nx.__version__}")
